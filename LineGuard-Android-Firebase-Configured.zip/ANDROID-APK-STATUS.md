# Android APK status — LineGuard

## Included in this package
- Expo SDK 54 Android app source and existing visual assets
- Reels-style feed, report submission with location/media, Shameboard, community posts, profile/reputation and conditional staff tools
- Firebase-backed data access and callable Cloud Functions source
- Email/password Firebase sign-up, sign-in and password reset; no Google Sign-In UI
- Confirmed sign-out flow with user-facing error handling
- Android APK GitHub Actions workflow

## Still blocking a verified APK/release
1. The Firebase Web API key supplied by the user has now been added to the web and native Firebase config, with an optional GitHub secret override.
2. Enable Firebase Email/Password auth and optionally Anonymous auth.
3. Deploy Cloud Functions, Firestore rules/indexes and Storage rules to `lineguard-68bb0`.
4. Restore the original Stripe server integration from its actual source/config. It is absent from the recovered ZIPs; no Stripe secret should be placed in client code.
5. Run the Android build workflow and test sign-in, sign-out, media, location, moderation, and payments on a physical device.

No APK was compiled in this environment: Android SDK, Gradle and Android build tools are not installed here.

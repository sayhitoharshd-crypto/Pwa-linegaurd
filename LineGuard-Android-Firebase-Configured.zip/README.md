# LineGuard Android source

This is the recovered LineGuard Expo/Firebase app prepared for an Android APK build. It keeps the dark plum/navy interface and purple-pink-orange brand gradients, with Reels, reporting, community, profile/reputation, staff moderation, appeals and the Shameboard.

## Authentication changes

- Google Sign-In has been removed from the login experience.
- Email/password account creation, sign-in and password-reset flows use Firebase Authentication.
- Anonymous sign-in and guest browsing remain available.
- Sign-out now asks for confirmation and catches/report errors rather than failing silently.
- Firebase sessions persist through the Firebase Auth SDK.

## Required Firebase setup before login can work

The API key in the previously saved project archive was rejected by Firebase (`auth/api-key-not-valid-please-pass-a-valid-api-key`). The key must be copied from Firebase Console for project `lineguard-68bb0` and supplied as `EXPO_PUBLIC_FIREBASE_API_KEY` at build time. Do not guess a key. The `.env.example` file shows the variable name.

In Firebase Console:
1. Project settings → General → Your apps → copy the current Web app API key.
2. Authentication → Sign-in method → enable Email/Password. Anonymous is optional if you want anonymous access.
3. Authentication → Settings → Authorized domains → add the deployed web domain if the web build is used.
4. Confirm API restrictions permit Firebase Authentication (`identitytoolkit.googleapis.com`) and token refresh (`securetoken.googleapis.com`).

The Cloud Functions, Firestore rules/indexes and Storage rules in this archive must also be deployed to `lineguard-68bb0` before protected actions, staff moderation, uploads, appeals and reputation updates can work. The original source notes indicate this deployment and physical-device verification have not yet been completed.

## Android APK build

A GitHub Actions workflow is included at `.github/workflows/android-apk.yml`. It builds a debug APK and uploads it as the `LineGuard-debug-apk` artifact. The workflow expects a repository secret named `FIREBASE_API_KEY` containing the current Firebase Web API key. The workflow itself has not been run in this environment.

## Stripe status

The recovered ZIPs do not include the original Stripe Checkout code, server routes, webhook handler, Stripe price IDs or payment environment configuration. They contain other payment/reputation references, but not enough to recreate the original Stripe flow safely. Preserve the original Stripe plans/prices, server-side Checkout, webhook-confirmed access and payment history only after the actual original Stripe backend code/configuration is available. Never place a Stripe secret key in the Android app or this repository.

## Build and test status

This is a prepared source archive, **not a compiled APK**. This environment has Java but no Android SDK, Gradle installation or Android build tools. The APK workflow has not run, and no physical-device test has been performed. Do not treat this archive as a release-ready production build until Firebase setup, Cloud Functions deployment, Stripe restoration and device tests are complete.

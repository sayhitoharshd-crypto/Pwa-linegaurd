# LineGuard development status

## Current app features in this archive
- Expo SDK 54 Android app with the dark plum/navy theme and purple-pink-orange gradients.
- Guest browsing and Reels-style public report feed.
- Firebase email/password sign-up, sign-in and password reset; Google Sign-In is not included in the login flow.
- Optional anonymous Firebase sign-in.
- Firebase-backed reporting, evidence upload, voting, moderation, appeals, community posts/likes, reputation and staff tools via callable Cloud Functions.
- Shameboard repeat-finding entries use opaque internal subject references and do not publish names/photos.
- Sign-out confirmation and visible error handling.

## Required before release
1. Supply the current valid Firebase Web API key using `EXPO_PUBLIC_FIREBASE_API_KEY`. The API key in earlier saved archives was rejected by Firebase.
2. Enable Email/Password in Firebase Authentication; optionally enable Anonymous.
3. Deploy Cloud Functions, Firestore rules/indexes and Storage rules to `lineguard-68bb0`.
4. Restore the original Stripe Checkout/backend/webhook implementation. It was not present in the recovered source archives, so this package does not claim to have live Stripe payments. Keep all Stripe secret keys server-side.
5. Build the APK using the included workflow and test authentication, reports, video, location, staff actions, appeals and payments on a physical Android device.

## Verification performed in this pass
- JavaScript/JSX syntax parsing passed for the modified auth, config, login, profile and database files.
- JSON configuration parsing passed.
- Cloud Functions and migration script passed Node syntax checks.
- Full dependency installation, Expo bundle, Android APK build, Firebase deployment, emulator tests and physical-device testing were not performed in this environment.

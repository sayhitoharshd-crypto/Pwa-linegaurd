import React, { useState } from 'react';
import { View, Text, Image, ScrollView, TextInput, TouchableOpacity, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../firebase/AuthContext';
import { Btn } from '../components/ui';
import { G } from '../theme';

export default function LoginScreen({ onBrowse }) {
  const { signInEmail, signUpEmail, resetPassword, signInAnon } = useAuth();
  const [mode, setMode] = useState('signin');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState('');

  const run = async (key, fn, successMessage) => {
    setBusy(key);
    try {
      await fn();
      if (successMessage) Alert.alert('LineGuard', successMessage);
    } catch (error) {
      const code = error?.code ? ` (${error.code})` : '';
      const message = error?.message || 'Please try again.';
      Alert.alert('LineGuard account error', `${message}${code}`);
    } finally {
      setBusy('');
    }
  };

  const submit = () => {
    const normalizedEmail = email.trim().toLowerCase();
    if (!normalizedEmail || !/^\S+@\S+\.\S+$/.test(normalizedEmail)) {
      Alert.alert('Check your email', 'Enter a valid email address.');
      return;
    }
    if (password.length < 6) {
      Alert.alert('Check your password', 'Your password must be at least 6 characters.');
      return;
    }
    if (mode === 'signup' && !name.trim()) {
      Alert.alert('Your name is required', 'Enter the name you want shown on your profile.');
      return;
    }
    return run('email', () => mode === 'signup'
      ? signUpEmail(name, normalizedEmail, password)
      : signInEmail(normalizedEmail, password));
  };

  const forgotPassword = () => {
    const normalizedEmail = email.trim().toLowerCase();
    if (!normalizedEmail) {
      Alert.alert('Enter your email', 'Type your account email first, then tap Forgot password.');
      return;
    }
    run('reset', () => resetPassword(normalizedEmail), 'Password reset email sent. Check your inbox.');
  };

  return (
    <LinearGradient colors={G.main} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ flex: 1 }}>
      <SafeAreaView style={{ flex: 1 }}>
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ flexGrow: 1, justifyContent: 'space-between', padding: 24 }}>
            <View style={{ alignItems: 'center', marginTop: 28 }}>
              <Image source={require('../../Assets/icon.png')} style={{ width: 88, height: 88, borderRadius: 26, marginBottom: 14 }} />
              <Text style={{ fontSize: 38, fontWeight: '900', color: '#fff', letterSpacing: -2 }}>LineGuard</Text>
              <Text style={{ fontSize: 14, color: 'rgba(255,255,255,0.85)', fontWeight: '700', marginTop: 8, textAlign: 'center', lineHeight: 22 }}>
                Queue Justice for India{ '\n' }Report line cutters. Stand up for fair queues.
              </Text>
            </View>

            <View style={{ backgroundColor: 'rgba(255,255,255,0.13)', borderRadius: 20, padding: 18, marginVertical: 22, borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)' }}>
              <View style={{ flexDirection: 'row', marginBottom: 16, backgroundColor: 'rgba(10,5,24,0.35)', borderRadius: 12, padding: 4 }}>
                {['signin', 'signup'].map((item) => (
                  <TouchableOpacity key={item} onPress={() => setMode(item)} style={{ flex: 1, paddingVertical: 11, borderRadius: 9, alignItems: 'center', backgroundColor: mode === item ? 'rgba(255,255,255,0.2)' : 'transparent' }}>
                    <Text style={{ color: '#fff', fontWeight: '900' }}>{item === 'signin' ? 'Sign In' : 'Create Account'}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              {mode === 'signup' ? (
                <TextInput value={name} onChangeText={setName} placeholder="Full name" placeholderTextColor="rgba(255,255,255,0.55)" autoCapitalize="words" style={fieldStyle} />
              ) : null}
              <TextInput value={email} onChangeText={setEmail} placeholder="Email address" placeholderTextColor="rgba(255,255,255,0.55)" autoCapitalize="none" autoCorrect={false} keyboardType="email-address" textContentType="emailAddress" style={fieldStyle} />
              <TextInput value={password} onChangeText={setPassword} placeholder="Password (at least 6 characters)" placeholderTextColor="rgba(255,255,255,0.55)" secureTextEntry textContentType={mode === 'signup' ? 'newPassword' : 'password'} style={[fieldStyle, { marginBottom: 12 }]} />

              <Btn title={busy === 'email' ? 'Please wait…' : mode === 'signup' ? 'Create Account' : 'Sign In'} onPress={submit} busy={busy === 'email'} />
              {mode === 'signin' ? (
                <TouchableOpacity onPress={forgotPassword} disabled={!!busy} style={{ padding: 12, alignItems: 'center' }}>
                  <Text style={{ color: 'rgba(255,255,255,0.88)', fontWeight: '800', fontSize: 12 }}>Forgot password?</Text>
                </TouchableOpacity>
              ) : null}
              <View style={{ height: 1, backgroundColor: 'rgba(255,255,255,0.18)', marginVertical: 10 }} />
              <Btn kind="outline" title="Continue anonymously" onPress={() => run('anon', signInAnon)} busy={busy === 'anon'} />
              {onBrowse ? <Btn kind="ghost" title="Browse as guest" onPress={onBrowse} /> : null}
            </View>

            <Text style={{ color: 'rgba(255,255,255,0.55)', fontSize: 11, textAlign: 'center', fontWeight: '600', lineHeight: 17, marginBottom: 8 }}>
              Your account name is not shown on public report cards. Avoid sharing private information or identifying details in evidence.
            </Text>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const fieldStyle = {
  color: '#fff',
  backgroundColor: 'rgba(12,5,28,0.35)',
  borderWidth: 1,
  borderColor: 'rgba(255,255,255,0.22)',
  borderRadius: 13,
  paddingHorizontal: 14,
  paddingVertical: 14,
  marginBottom: 10,
  fontSize: 14,
  fontWeight: '600',
};

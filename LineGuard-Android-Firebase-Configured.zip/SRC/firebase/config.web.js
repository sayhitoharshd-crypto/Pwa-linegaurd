import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import { getFunctions } from 'firebase/functions';

const apiKey = process.env.EXPO_PUBLIC_FIREBASE_API_KEY || 'AIzaSyCSTU6elUZN2i8z3wgZVlhoKISxjA3bMp4';
export const hasFirebaseApiKey = Boolean(apiKey && !apiKey.includes('REPLACE_'));

const firebaseConfig = {
  apiKey: apiKey || 'MISSING_FIREBASE_WEB_API_KEY',
  authDomain: 'lineguard-68bb0.firebaseapp.com',
  projectId: 'lineguard-68bb0',
  storageBucket: 'lineguard-68bb0.firebasestorage.app',
  messagingSenderId: '677986213198',
  appId: '1:677986213198:web:88dc4d6c409ec636b9d21f',
  measurementId: 'G-1JCVTRDZWJ',
};

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export const functions = getFunctions(app, 'asia-south1');

import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  onAuthStateChanged,
  signInAnonymously,
  signOut,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  updateProfile,
} from 'firebase/auth';
import { auth, hasFirebaseApiKey } from './config';
import { ensureUser, isStaff, listenUser } from './db';

const Ctx = createContext(null);
export const useAuth = () => useContext(Ctx);

function requireFirebaseApiKey() {
  if (!hasFirebaseApiKey) {
    throw new Error('LineGuard needs the current Firebase Web API key. Set EXPO_PUBLIC_FIREBASE_API_KEY from Firebase Console > Project settings > General.');
  }
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [staff, setStaff] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let unsubProfile = () => {};
    const unsub = onAuthStateChanged(auth, async (u) => {
      unsubProfile();
      setUser(u);
      setProfile(null);
      setStaff(false);
      if (u) {
        try {
          await ensureUser();
          setStaff(await isStaff(u.uid));
        } catch (error) {
          // Keep authentication state available; protected server actions will
          // surface their own actionable error if backend setup is incomplete.
        }
        unsubProfile = listenUser(u.uid, setProfile, () => setProfile(null));
      }
      setLoading(false);
    });
    return () => { unsub(); unsubProfile(); };
  }, []);

  const signInEmail = async (email, password) => {
    requireFirebaseApiKey();
    return signInWithEmailAndPassword(auth, email.trim().toLowerCase(), password);
  };

  const signUpEmail = async (name, email, password) => {
    requireFirebaseApiKey();
    const credential = await createUserWithEmailAndPassword(auth, email.trim().toLowerCase(), password);
    await updateProfile(credential.user, { displayName: name.trim() });
    return credential;
  };

  const resetPassword = async (email) => {
    requireFirebaseApiKey();
    return sendPasswordResetEmail(auth, email.trim().toLowerCase());
  };

  const signInAnon = async () => {
    requireFirebaseApiKey();
    return signInAnonymously(auth);
  };

  const logout = async () => {
    // Firebase signOut clears the persisted session and triggers the auth listener.
    await signOut(auth);
  };

  const value = {
    user,
    profile,
    staff,
    loading,
    displayName: user?.isAnonymous ? 'Anonymous' : (user?.displayName?.split(' ')[0] || 'User'),
    rep: profile?.rep ?? 100,
    signInEmail,
    signUpEmail,
    resetPassword,
    signInAnon,
    logout,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

# Firebase configuration applied

The Firebase Web app configuration supplied for project `lineguard-68bb0` has been applied to:
- `SRC/firebase/config.js` (React Native persistence)
- `SRC/firebase/config.web.js` (web persistence)

The public Firebase Web API key is included as a fallback in these client config files. The GitHub Actions workflow accepts an optional `FIREBASE_API_KEY` repository secret override. No service-account credential or Stripe secret is included.

Before testing sign-in, open Firebase Console → Authentication → Sign-in method and enable **Email/Password**. Enable Anonymous only if the guest/anonymous entry option is intended. Do not enable Google sign-in.

The Android workflow now uses `npm install` because this source archive does not include a package lockfile. It builds a debug APK and uploads it as the `LineGuard-debug-apk` artifact. The workflow must be run in GitHub Actions before an APK exists.

import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import React, { useRef, useState } from "react";
import {
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { PostComment, useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

function timeAgo(ts: string) {
  const d = Date.now() - new Date(ts).getTime();
  const m = Math.floor(d / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

function CommentItem({ comment, postId }: { comment: PostComment; postId: string }) {
  const colors = useColors();
  const { upvoteComment, authUser } = useApp();
  const voted = comment.upvotedBy.includes(authUser?.id ?? "");

  return (
    <View style={[styles.commentCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={styles.commentLeft}>
        <View style={[styles.commentAvatar, { backgroundColor: comment.authorColor }]}>
          <Text style={styles.commentAvatarText}>{comment.authorName[0]}</Text>
        </View>
        <View style={[styles.commentThread, { backgroundColor: colors.border }]} />
      </View>
      <View style={styles.commentRight}>
        <View style={styles.commentHeader}>
          <Text style={[styles.commentAuthor, { color: colors.foreground }]}>{comment.authorName}</Text>
          <Text style={[styles.commentTime, { color: colors.mutedForeground }]}>{timeAgo(comment.createdAt)}</Text>
        </View>
        <Text style={[styles.commentBody, { color: colors.foreground }]}>{comment.content}</Text>
        <TouchableOpacity
          onPress={() => {
            upvoteComment(postId, comment.id);
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          }}
          style={styles.commentVote}
        >
          <Feather name="arrow-up" size={12} color={voted ? colors.primary : colors.mutedForeground} />
          <Text style={[styles.commentVoteCount, { color: voted ? colors.primary : colors.mutedForeground }]}>
            {comment.upvotes}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

export default function PostDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { getPostById, upvotePost, addComment, authUser } = useApp();
  const [commentText, setCommentText] = useState("");
  const inputRef = useRef<TextInput>(null);

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;
  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const post = getPostById(id ?? "");
  if (!post) {
    return (
      <View style={[styles.notFound, { backgroundColor: colors.background }]}>
        <TouchableOpacity onPress={() => router.back()} style={[styles.goBack, { backgroundColor: colors.primary }]}>
          <Text style={{ color: "#FFF", fontFamily: "Inter_700Bold" }}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const voted = post.upvotedBy.includes(authUser?.id ?? "");

  const handleComment = () => {
    if (!commentText.trim()) return;
    addComment(post.id, commentText.trim());
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setCommentText("");
    inputRef.current?.blur();
  };

  const ListHeader = (
    <View>
      <LinearGradient
        colors={[colors.gradientStart, colors.gradientMid]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.header, { paddingTop: topPad + 12 }]}
      >
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Feather name="arrow-left" size={22} color="rgba(255,255,255,0.9)" />
        </TouchableOpacity>
        <View style={styles.communityChip}>
          <Feather name="users" size={12} color="rgba(255,255,255,0.8)" />
          <Text style={styles.communityChipText}>{post.communityName}</Text>
        </View>
      </LinearGradient>

      <View style={[styles.postBody, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.postTitle, { color: colors.foreground }]}>{post.title}</Text>
        <Text style={[styles.postContent, { color: colors.foreground }]}>{post.content}</Text>

        <View style={styles.postMeta}>
          <View style={[styles.authorBadge, { backgroundColor: post.authorColor + "22" }]}>
            <View style={[styles.authorDot, { backgroundColor: post.authorColor }]}>
              <Text style={styles.authorDotText}>{post.authorName[0]}</Text>
            </View>
            <Text style={[styles.authorName, { color: post.authorColor }]}>{post.authorName}</Text>
          </View>
          <Text style={[styles.postTime, { color: colors.mutedForeground }]}>{timeAgo(post.createdAt)}</Text>
        </View>

        <View style={styles.postActions}>
          <TouchableOpacity
            onPress={() => {
              upvotePost(post.id);
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            }}
            style={[styles.actionBtn, { backgroundColor: voted ? colors.primary + "20" : colors.muted }]}
          >
            <Feather name="arrow-up" size={16} color={voted ? colors.primary : colors.mutedForeground} />
            <Text style={[styles.actionCount, { color: voted ? colors.primary : colors.mutedForeground }]}>
              {post.upvotes}
            </Text>
          </TouchableOpacity>
          <View style={[styles.actionBtn, { backgroundColor: colors.muted }]}>
            <Feather name="message-square" size={16} color={colors.mutedForeground} />
            <Text style={[styles.actionCount, { color: colors.mutedForeground }]}>
              {post.comments.length} {post.comments.length === 1 ? "comment" : "comments"}
            </Text>
          </View>
        </View>
      </View>

      <View style={styles.commentsHeader}>
        <Feather name="message-square" size={14} color={colors.mutedForeground} />
        <Text style={[styles.commentsLabel, { color: colors.mutedForeground }]}>
          {post.comments.length} Comments
        </Text>
      </View>
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <FlatList
        data={post.comments}
        keyExtractor={item => item.id}
        renderItem={({ item }) => <CommentItem comment={item} postId={post.id} />}
        ListHeaderComponent={ListHeader}
        contentContainerStyle={[styles.list, { paddingBottom: 80 + bottomPad }]}
        showsVerticalScrollIndicator={false}
        scrollEnabled
        ListEmptyComponent={
          <View style={styles.emptyComments}>
            <Feather name="message-circle" size={32} color={colors.mutedForeground} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>No comments yet — be the first!</Text>
          </View>
        }
      />

      <View style={[styles.inputBar, { backgroundColor: colors.card, borderTopColor: colors.border, paddingBottom: bottomPad + 8 }]}>
        <View style={[styles.inputWrap, { backgroundColor: colors.muted, borderColor: colors.border }]}>
          <View style={[styles.inputAvatar, { backgroundColor: authUser?.color ?? colors.primary }]}>
            <Text style={styles.inputAvatarText}>{(authUser?.name ?? "U")[0]}</Text>
          </View>
          <TextInput
            ref={inputRef}
            style={[styles.commentInput, { color: colors.foreground }]}
            placeholder="Add a comment..."
            placeholderTextColor={colors.mutedForeground}
            value={commentText}
            onChangeText={setCommentText}
            multiline
          />
        </View>
        <Pressable
          onPress={handleComment}
          disabled={!commentText.trim()}
          style={({ pressed }) => [
            styles.sendBtn,
            { backgroundColor: commentText.trim() ? colors.primary : colors.muted, opacity: pressed ? 0.8 : 1 },
          ]}
        >
          <Feather name="send" size={18} color={commentText.trim() ? "#FFF" : colors.mutedForeground} />
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  notFound: { flex: 1, alignItems: "center", justifyContent: "center" },
  goBack: { paddingHorizontal: 20, paddingVertical: 10, borderRadius: 10 },
  header: { paddingHorizontal: 16, paddingBottom: 16, gap: 10 },
  backBtn: { width: 40, height: 40, alignItems: "center", justifyContent: "center" },
  communityChip: { flexDirection: "row", alignItems: "center", gap: 6, alignSelf: "flex-start", backgroundColor: "rgba(255,255,255,0.2)", paddingHorizontal: 12, paddingVertical: 5, borderRadius: 20 },
  communityChipText: { color: "rgba(255,255,255,0.9)", fontSize: 12, fontFamily: "Inter_600SemiBold" },
  postBody: { margin: 16, borderRadius: 18, borderWidth: 1, padding: 16, gap: 12 },
  postTitle: { fontSize: 18, fontFamily: "Inter_700Bold", lineHeight: 26 },
  postContent: { fontSize: 14, fontFamily: "Inter_400Regular", lineHeight: 22 },
  postMeta: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  authorBadge: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20 },
  authorDot: { width: 20, height: 20, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  authorDotText: { color: "#FFF", fontSize: 9, fontFamily: "Inter_700Bold" },
  authorName: { fontSize: 13, fontFamily: "Inter_700Bold" },
  postTime: { fontSize: 12, fontFamily: "Inter_400Regular" },
  postActions: { flexDirection: "row", gap: 10 },
  actionBtn: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20 },
  actionCount: { fontSize: 13, fontFamily: "Inter_700Bold" },
  commentsHeader: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 20, paddingBottom: 6 },
  commentsLabel: { fontSize: 13, fontFamily: "Inter_700Bold", letterSpacing: 0.5 },
  list: { paddingTop: 0 },
  commentCard: { flexDirection: "row", marginHorizontal: 16, marginVertical: 4, borderRadius: 14, borderWidth: 1, padding: 12, gap: 10 },
  commentLeft: { alignItems: "center", gap: 4 },
  commentAvatar: { width: 28, height: 28, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  commentAvatarText: { color: "#FFF", fontSize: 11, fontFamily: "Inter_700Bold" },
  commentThread: { flex: 1, width: 2, borderRadius: 1, minHeight: 10 },
  commentRight: { flex: 1, gap: 5 },
  commentHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  commentAuthor: { fontSize: 13, fontFamily: "Inter_700Bold" },
  commentTime: { fontSize: 11, fontFamily: "Inter_400Regular" },
  commentBody: { fontSize: 13, fontFamily: "Inter_400Regular", lineHeight: 19 },
  commentVote: { flexDirection: "row", alignItems: "center", gap: 4, alignSelf: "flex-start" },
  commentVoteCount: { fontSize: 12, fontFamily: "Inter_700Bold" },
  emptyComments: { alignItems: "center", paddingTop: 30, gap: 8, paddingHorizontal: 20 },
  emptyText: { fontSize: 14, fontFamily: "Inter_400Regular", textAlign: "center" },
  inputBar: { position: "absolute", bottom: 0, left: 0, right: 0, flexDirection: "row", alignItems: "flex-end", gap: 10, paddingHorizontal: 16, paddingTop: 10, borderTopWidth: 1 },
  inputWrap: { flex: 1, flexDirection: "row", alignItems: "flex-end", borderRadius: 24, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 8, gap: 8 },
  inputAvatar: { width: 24, height: 24, borderRadius: 12, alignItems: "center", justifyContent: "center", marginBottom: 2 },
  inputAvatarText: { color: "#FFF", fontSize: 9, fontFamily: "Inter_700Bold" },
  commentInput: { flex: 1, fontSize: 14, fontFamily: "Inter_400Regular", maxHeight: 100 },
  sendBtn: { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center" },
});

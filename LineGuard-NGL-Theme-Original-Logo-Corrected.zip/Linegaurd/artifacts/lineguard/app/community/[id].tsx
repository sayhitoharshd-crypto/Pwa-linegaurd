import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { CommunityPost, useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

function timeAgo(ts: string) {
  const d = Date.now() - new Date(ts).getTime();
  const m = Math.floor(d / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h`;
  return `${Math.floor(h / 24)}d`;
}

function PostCard({ post, onPress }: { post: CommunityPost; onPress: () => void }) {
  const colors = useColors();
  const { upvotePost, authUser } = useApp();
  const voted = post.upvotedBy.includes(authUser?.id ?? "");

  return (
    <Pressable
      onPress={onPress}
      style={[styles.postCard, { backgroundColor: colors.card, borderColor: colors.border }]}
    >
      <View style={styles.postLeft}>
        <TouchableOpacity
          onPress={(e) => {
            e.stopPropagation();
            upvotePost(post.id);
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          }}
          style={[styles.voteBtn, { backgroundColor: voted ? colors.primary + "20" : colors.muted }]}
        >
          <Feather name="arrow-up" size={14} color={voted ? colors.primary : colors.mutedForeground} />
          <Text style={[styles.voteCount, { color: voted ? colors.primary : colors.mutedForeground }]}>
            {post.upvotes}
          </Text>
        </TouchableOpacity>
      </View>
      <View style={styles.postRight}>
        <Text style={[styles.postTitle, { color: colors.foreground }]} numberOfLines={2}>
          {post.title}
        </Text>
        <Text style={[styles.postContent, { color: colors.mutedForeground }]} numberOfLines={2}>
          {post.content}
        </Text>
        <View style={styles.postMeta}>
          <View style={[styles.authorDot, { backgroundColor: post.authorColor }]}>
            <Text style={styles.authorDotText}>{post.authorName[0]}</Text>
          </View>
          <Text style={[styles.authorName, { color: colors.mutedForeground }]}>{post.authorName}</Text>
          <Text style={[styles.dot, { color: colors.mutedForeground }]}>·</Text>
          <Text style={[styles.timeText, { color: colors.mutedForeground }]}>{timeAgo(post.createdAt)}</Text>
          <Text style={[styles.dot, { color: colors.mutedForeground }]}>·</Text>
          <Feather name="message-square" size={11} color={colors.mutedForeground} />
          <Text style={[styles.timeText, { color: colors.mutedForeground }]}>{post.comments.length}</Text>
        </View>
      </View>
    </Pressable>
  );
}

export default function CommunityDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { getCommunityById, getPostsByCommunity, isMember, joinCommunity, leaveCommunity, createPost } = useApp();

  const [postModalVisible, setPostModalVisible] = useState(false);
  const [postTitle, setPostTitle] = useState("");
  const [postContent, setPostContent] = useState("");
  const [posting, setPosting] = useState(false);

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const community = getCommunityById(id ?? "");
  const posts = getPostsByCommunity(id ?? "");
  const member = isMember(id ?? "");

  if (!community) {
    return (
      <View style={[styles.notFound, { backgroundColor: colors.background }]}>
        <Text style={[{ color: colors.foreground, fontSize: 16, fontFamily: "Inter_600SemiBold" }]}>Community not found</Text>
        <TouchableOpacity onPress={() => router.back()} style={[styles.backBtn, { backgroundColor: colors.primary }]}>
          <Text style={{ color: "#FFF", fontFamily: "Inter_700Bold" }}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const handlePost = async () => {
    if (!postTitle.trim()) return;
    setPosting(true);
    await new Promise(r => setTimeout(r, 300));
    createPost(id ?? "", community.name, postTitle.trim(), postContent.trim());
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setPostTitle("");
    setPostContent("");
    setPosting(false);
    setPostModalVisible(false);
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <LinearGradient
        colors={[community.color + "EE", community.color + "99"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.header, { paddingTop: topPad + 12 }]}
      >
        <TouchableOpacity onPress={() => router.back()} style={styles.headerBack}>
          <Feather name="arrow-left" size={22} color="rgba(255,255,255,0.9)" />
        </TouchableOpacity>
        <View style={styles.headerContent}>
          <View style={[styles.commIcon, { backgroundColor: "rgba(255,255,255,0.25)" }]}>
            <Feather name={(({ Transport: "navigation", Healthcare: "heart", Workplace: "briefcase" } as any)[community.category] ?? "hash") as any} size={20} color="#FFF" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.commName} numberOfLines={1}>{community.name}</Text>
            <Text style={styles.commDesc} numberOfLines={2}>{community.description}</Text>
          </View>
          <TouchableOpacity
            onPress={() => {
              if (member) leaveCommunity(id ?? "");
              else joinCommunity(id ?? "");
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            }}
            style={[styles.joinBtn, { backgroundColor: member ? "rgba(255,255,255,0.2)" : "#FFF" }]}
          >
            <Text style={[styles.joinText, { color: member ? "#FFF" : community.color }]}>
              {member ? "Joined ✓" : "Join"}
            </Text>
          </TouchableOpacity>
        </View>
        <View style={styles.commStats}>
          <Text style={styles.commStat}>{community.memberIds.length} members</Text>
          <Text style={styles.commStatDot}>·</Text>
          <Text style={styles.commStat}>{posts.length} posts</Text>
          <Text style={styles.commStatDot}>·</Text>
          <Text style={styles.commStat}>{community.category}</Text>
        </View>
      </LinearGradient>

      <FlatList
        data={posts}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <PostCard post={item} onPress={() => router.push(`/community/post/${item.id}`)} />
        )}
        contentContainerStyle={[styles.list, { paddingBottom: 120 + bottomPad }]}
        showsVerticalScrollIndicator={false}
        scrollEnabled={!!posts.length}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Feather name="file-text" size={40} color={colors.mutedForeground} />
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No posts yet</Text>
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Be the first to start a discussion</Text>
          </View>
        }
      />

      <Pressable
        onPress={() => setPostModalVisible(true)}
        style={[styles.fab, { bottom: 90 + bottomPad, backgroundColor: community.color }]}
      >
        <Feather name="edit-3" size={22} color="#FFF" />
      </Pressable>

      <Modal visible={postModalVisible} transparent animationType="slide">
        <Pressable style={styles.overlay} onPress={() => !posting && setPostModalVisible(false)}>
          <Pressable
            style={[styles.modalCard, { backgroundColor: colors.card, borderColor: colors.border }]}
            onPress={e => e.stopPropagation()}
          >
            <View style={styles.modalHandle} />
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>New Post</Text>
            <TextInput
              style={[styles.titleInput, { backgroundColor: colors.muted, color: colors.foreground, borderColor: colors.border }]}
              placeholder="Post title..."
              placeholderTextColor={colors.mutedForeground}
              value={postTitle}
              onChangeText={setPostTitle}
            />
            <TextInput
              style={[styles.bodyInput, { backgroundColor: colors.muted, color: colors.foreground, borderColor: colors.border }]}
              placeholder="Share your thoughts, experience, or question..."
              placeholderTextColor={colors.mutedForeground}
              value={postContent}
              onChangeText={setPostContent}
              multiline
              textAlignVertical="top"
            />
            <View style={styles.modalBtns}>
              <TouchableOpacity onPress={() => setPostModalVisible(false)} style={[styles.cancelBtn, { backgroundColor: colors.muted }]}>
                <Text style={[{ fontFamily: "Inter_600SemiBold", fontSize: 15 }, { color: colors.mutedForeground }]}>Cancel</Text>
              </TouchableOpacity>
              <Pressable onPress={handlePost} disabled={posting || !postTitle.trim()} style={{ flex: 2, borderRadius: 12, overflow: "hidden" }}>
                <LinearGradient
                  colors={[colors.gradientStart, colors.gradientMid]}
                  start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                  style={[styles.postBtn, { opacity: !postTitle.trim() ? 0.5 : 1 }]}
                >
                  {posting ? <ActivityIndicator color="#FFF" /> : <Text style={styles.postBtnText}>Post</Text>}
                </LinearGradient>
              </Pressable>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  notFound: { flex: 1, alignItems: "center", justifyContent: "center", gap: 16 },
  backBtn: { paddingHorizontal: 20, paddingVertical: 10, borderRadius: 10 },
  header: { paddingHorizontal: 16, paddingBottom: 16, gap: 10 },
  headerBack: { width: 40, height: 40, alignItems: "center", justifyContent: "center" },
  headerContent: { flexDirection: "row", alignItems: "flex-start", gap: 12 },
  commIcon: { width: 44, height: 44, borderRadius: 22, alignItems: "center", justifyContent: "center" },
  commName: { color: "#FFF", fontSize: 17, fontFamily: "Inter_700Bold" },
  commDesc: { color: "rgba(255,255,255,0.75)", fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 2 },
  joinBtn: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20 },
  joinText: { fontSize: 13, fontFamily: "Inter_700Bold" },
  commStats: { flexDirection: "row", alignItems: "center", gap: 6 },
  commStat: { color: "rgba(255,255,255,0.7)", fontSize: 12, fontFamily: "Inter_500Medium" },
  commStatDot: { color: "rgba(255,255,255,0.4)", fontSize: 12 },
  list: { paddingTop: 8 },
  postCard: {
    flexDirection: "row",
    marginHorizontal: 16,
    marginVertical: 5,
    borderRadius: 16,
    borderWidth: 1,
    padding: 12,
    gap: 10,
    ...Platform.select({
      ios: { shadowColor: "#6D28D9", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.07, shadowRadius: 8 },
      android: { elevation: 2 },
    }),
  },
  postLeft: { alignItems: "center", gap: 4 },
  voteBtn: { borderRadius: 20, padding: 8, alignItems: "center", gap: 2 },
  voteCount: { fontSize: 12, fontFamily: "Inter_700Bold" },
  postRight: { flex: 1, gap: 5 },
  postTitle: { fontSize: 14, fontFamily: "Inter_700Bold", lineHeight: 20 },
  postContent: { fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 18 },
  postMeta: { flexDirection: "row", alignItems: "center", gap: 5, flexWrap: "wrap" },
  authorDot: { width: 16, height: 16, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  authorDotText: { color: "#FFF", fontSize: 8, fontFamily: "Inter_700Bold" },
  authorName: { fontSize: 11, fontFamily: "Inter_500Medium" },
  dot: { fontSize: 11 },
  timeText: { fontSize: 11, fontFamily: "Inter_400Regular" },
  empty: { alignItems: "center", paddingTop: 60, gap: 10 },
  emptyTitle: { fontSize: 17, fontFamily: "Inter_700Bold", marginTop: 8 },
  emptyText: { fontSize: 14, fontFamily: "Inter_400Regular", color: "#999" },
  fab: {
    position: "absolute",
    right: 20,
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: "center",
    justifyContent: "center",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
    elevation: 8,
  },
  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.55)", justifyContent: "flex-end" },
  modalCard: { borderTopLeftRadius: 24, borderTopRightRadius: 24, borderWidth: 1, padding: 24, gap: 14 },
  modalHandle: { width: 36, height: 4, borderRadius: 2, backgroundColor: "#DDD", alignSelf: "center", marginBottom: 4 },
  modalTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  titleInput: { borderRadius: 12, borderWidth: 1, padding: 14, fontSize: 15, fontFamily: "Inter_600SemiBold" },
  bodyInput: { borderRadius: 12, borderWidth: 1, padding: 14, fontSize: 14, fontFamily: "Inter_400Regular", minHeight: 100, lineHeight: 20 },
  modalBtns: { flexDirection: "row", gap: 10 },
  cancelBtn: { flex: 1, padding: 14, borderRadius: 12, alignItems: "center" },
  postBtn: { padding: 14, alignItems: "center", borderRadius: 12 },
  postBtnText: { color: "#FFF", fontSize: 15, fontFamily: "Inter_700Bold" },
});
